package com.project.CalculatorTesting.CalculatorTesting;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BankAccountTest {

    @Test
    public void testDepositIncreasesBalance() {
        BankAccount account = new BankAccount(100.0);
        account.deposit(50.0);
        Assertions.assertEquals(150.0, account.getBalance(), 0.001);
    }

    @Test
    public void testWithdrawDecreasesBalance() {
        BankAccount account = new BankAccount(200.0);
        account.withdraw(75.0);
        Assertions.assertEquals(125.0, account.getBalance(), 0.001);
    }

    @Test
    public void testWithdrawMoreThanBalanceThrowsRuntimeException() {
        BankAccount account = new BankAccount(50.0);
        Assertions.assertThrows(RuntimeException.class, () -> {
            account.withdraw(100.0);
        }, "Should throw RuntimeException for insufficient funds.");
    }

    @Test
    public void testNegativeOpeningBalanceThrowsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new BankAccount(-100.0);
        }, "Should throw IllegalArgumentException for a negative opening balance.");
    }
}
