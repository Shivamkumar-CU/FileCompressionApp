package com.project.CalculatorTesting.CalculatorTesting;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
public class CalculatorTest {

	 @Test
	    public void testAdd() {
	        // Step 1: Create an instance of the class to test
	        Calculator calculator = new Calculator();

	        // Step 2: Call the method with test data
	        int result = calculator.add(2, 3);

	        // Step 3: Check the expected output
	        assertEquals(5, result, "2 + 3 should equal 5");
	    }
}
