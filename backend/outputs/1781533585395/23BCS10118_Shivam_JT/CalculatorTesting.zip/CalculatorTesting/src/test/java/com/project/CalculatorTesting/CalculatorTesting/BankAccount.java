package com.project.CalculatorTesting.CalculatorTesting;

public class BankAccount {
    private double balance;

    public BankAccount(double opening) {
        if (opening < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative.");
        }
        this.balance = opening;
    }

    public void deposit(double amt) {
        if (amt <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive.");
        }
        balance += amt;
    }

    public void withdraw(double amt) {
        if (amt <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive.");
        }
        if (amt > balance) {
            throw new RuntimeException("Insufficient funds");
        }
        balance -= amt;
    }

    public double getBalance() {
        return balance;
    }
}