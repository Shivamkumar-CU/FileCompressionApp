package com.project.CalculatorTesting.CalculatorTesting;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MathUtilsTest {

    @Test
    void testSquareRootThrowsExceptionForNegativeInput() {
        int negativeInput = -4;

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> MathUtils.squareRoot(negativeInput)
        );

        assertEquals("Number must be non-negative", exception.getMessage());
    }
}

