package com.project.CalculatorTesting.CalculatorTesting;

public class MathUtils {
    public static int squareRoot(int number) {
        if (number < 0) {
            throw new IllegalArgumentException("Number must be non-negative");
        }
        return (int) Math.sqrt(number);
    }
}
