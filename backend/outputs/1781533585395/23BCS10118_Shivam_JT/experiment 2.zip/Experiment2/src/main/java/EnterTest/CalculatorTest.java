package EnterTest;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.expectThrows;

public class CalculatorTest {
    Calculator c = new Calculator();
    @Test
    public void testAdd() {
        assertEquals(c.add(5, 5), 10);}
    @Test
    public void testSubtract() {
        assertEquals(c.subtract(5, 4), 1);}
    @Test
    public void testMultiply() {
        assertEquals(c.multiply(4, 5), 20);}
    @Test
    public void testDivide() {
        assertEquals(c.divide(10,2), 2);}
    @Test
    public void testDivideByZero() {
        ArithmeticException exception = expectThrows(ArithmeticException.class, () -> c.divide(10,0));
        assertEquals(exception.getMessage(), "Divide by zero is not allowed.");}
}


        
    
//    public void assertEquals(int x,int y){
//        if(x==y){
//            System.out.println("pass:"+y+"=="+y);
//        }else{
//            System.out.println("fail:y"+y+x);
//        }}
//    public static void main(String[]args) {
//        CalculatorTest test = new CalculatorTest();
//        test.testAdd();
    

