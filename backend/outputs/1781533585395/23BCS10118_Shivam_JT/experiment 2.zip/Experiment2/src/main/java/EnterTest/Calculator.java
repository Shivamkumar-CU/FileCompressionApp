package EnterTest;

class Calculator {
    public int add(int a, int b) {
        return a + b;
    }public int subtract(int a, int b) {
        return a - b;
    }public int multiply(int a, int b) {
        return a * b;
    }public double divide(int a, int b) 
    {if(b == 0)
            throw new ArithmeticException("Division by zero is not possible");
        return (double) a / b;
    }}
